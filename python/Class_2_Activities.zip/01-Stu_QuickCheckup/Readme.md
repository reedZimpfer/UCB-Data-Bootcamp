# Quick Check-Up

Let’s start with a quick warm-up activity to get the Python juices flowing.

## Instructions

Create a simple Python command line application that does the following:

* Prints "Hello User!"

* Then asks "What is your name?"

* Then responds "Hello &lt;user's name&gt;"

* Then asks: "What is your favorite number? "

* Then responds: "Your favorite number is lower than mine.", "Your favorite number is higher than mine.", or "Your favorite number is the same as mine!" depending on your favorite number.


## Hint

* Remember to cast your variables!

—

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
